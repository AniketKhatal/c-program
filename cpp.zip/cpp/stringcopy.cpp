//Program Name:copy the string 

#include<iostream>
using namespace std;
int main()     //main function
{
	string s1,s2;
	cout<<"Enter the string :";
	getline(cin,s1);
	s2=s1;
	cout<<"The copied string :"<<s2; 
	return 0;
}

