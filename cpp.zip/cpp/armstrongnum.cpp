//Program Name:Armstrong number in cpp;

#include<iostream>
using namespace std;
int main()
{
	int num;
	cout<<"Enter the number :";
	cin>>num;
	return 0;
}
